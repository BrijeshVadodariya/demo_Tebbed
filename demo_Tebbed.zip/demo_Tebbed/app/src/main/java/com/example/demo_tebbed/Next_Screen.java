package com.example.demo_tebbed;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class Next_Screen extends AppCompatActivity {

    TextView hname,details,show_facility,doctor_list;
    String dname="";
    String str;
    String []splitterString;
    RecyclerView recyclerView;
    StringRequest stringRequest;
    RequestQueue requestQueue;
    String url = "";
    String url1 = "";
    String url2 = "";
    CustomAdapter customAdapter;
    String h_name;
    String h_add,h_number,h_email,h_website,h_locaion,h_time;
    String h_spc="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next__screen);

        hname = findViewById(R.id.hname);
        details = findViewById(R.id.details);
        show_facility = findViewById(R.id.show_facility);
        doctor_list = findViewById(R.id.doctor_list);

        Intent intent = getIntent();
        str = intent.getStringExtra("data");

        splitterString=str.split("\"");
        for (String s : splitterString) {
            //System.out.println("00000000000000"+s);
        }

        // Toast.makeText(this, ""+splitterString[3], Toast.LENGTH_SHORT).show();
        String s = splitterString[3];


        url = "http://rmcfindhospital.dx.am/getdata.php?id="+s;
        url1 = "http://rmcfindhospital.dx.am/facility.php?id="+s;
        url2 = "http://rmcfindhospital.dx.am/doctor.php?id="+s;

        fetchDataFromInternet();
        fetchDataFromInternet1();
        fetchDataFromInternet2();

    }

    public void fetchDataFromInternet() {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();
        requestQueue = Volley.newRequestQueue(Next_Screen.this);
        stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("hospitallist");

                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObject = jsonArray.getJSONObject(i);
                        h_name = jsonObject.getString("h_name");
                        h_add= jsonObject.getString("h_address");
                        h_number = jsonObject.getString("h_number");
                        h_email = jsonObject.getString("h_email");
                        h_website = jsonObject.getString("h_website");
                        h_locaion = jsonObject.getString("h_location");
                        h_time = jsonObject.getString("h_time");
                    }
                    System.out.print("AAAA"+h_name+h_add);
                    //  Toast.makeText(Next_Screen.this, "aa "+h_name, Toast.LENGTH_SHORT).show();
                    hname.setText(h_name);
                    String values="Address:- "+h_add+"\n"+"Number:- "+h_number+"\n"+"Email:- "+h_email+"\n"+"Website:- "+h_website+"\n"+"Location:- "+h_locaion+"\n"+"Time:- "+h_time;
                    details.setText(values);
                    progressDialog.dismiss();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });
        requestQueue.add(stringRequest);
    }







    public void fetchDataFromInternet1() {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();
        requestQueue = Volley.newRequestQueue(Next_Screen.this);
        stringRequest = new StringRequest(Request.Method.GET, url1, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("hospitallist");

                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObject = jsonArray.getJSONObject(i);
                        h_spc =h_spc+"  "+jsonObject.getString("f_name");

                    }
                    show_facility.setText("Facility of Hospital:- "+h_spc);


                    progressDialog.dismiss();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });
        requestQueue.add(stringRequest);
    }




    public void fetchDataFromInternet2() {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();
        requestQueue = Volley.newRequestQueue(Next_Screen.this);
        stringRequest = new StringRequest(Request.Method.GET, url2, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("hospitallist");

                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObject = jsonArray.getJSONObject(i);
                        dname =dname+"  "+jsonObject.getString("d_name")+"\n";

                    }
                    doctor_list.setText(dname);


                    progressDialog.dismiss();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });
        requestQueue.add(stringRequest);
    }

}
